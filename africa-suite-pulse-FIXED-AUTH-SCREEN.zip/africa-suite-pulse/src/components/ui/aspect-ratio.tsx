import { Root } from "@radix-ui/react-aspect-ratio"

const AspectRatio = Root

export { AspectRatio }
