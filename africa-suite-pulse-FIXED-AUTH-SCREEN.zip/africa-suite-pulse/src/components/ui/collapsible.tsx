import { Root, Trigger, Content } from "@radix-ui/react-collapsible"

const Collapsible = Root
const CollapsibleTrigger = Trigger
const CollapsibleContent = Content

export { Collapsible, CollapsibleTrigger, CollapsibleContent }
