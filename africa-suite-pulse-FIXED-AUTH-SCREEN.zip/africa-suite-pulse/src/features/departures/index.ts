export { default as DeparturesPage } from './DeparturesPage';
export * from './departures.types';